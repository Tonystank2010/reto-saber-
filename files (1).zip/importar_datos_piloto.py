#!/usr/bin/env python3
"""Suma a la base los datos del piloto exportados desde el juego (Perfil > Datos del piloto > Exportar).

Uso:   python3 importar_datos_piloto.py datos-piloto-1.json [datos-piloto-2.json ...] [--db banco-preguntas.db] [--aplicar-niveles]

- Acumula intentos, aciertos, tiempo y opciones elegidas por pregunta.
- Guarda los reportes (marca esas preguntas como 'revisar'), la validación del puntaje y la retención.
- Un mismo archivo no se importa dos veces.
- Informa: preguntas muy difíciles o lentas, preguntas donde una opción incorrecta atrae más que la correcta,
  retención, validación del puntaje y SUGERENCIAS de cambio de nivel (recalibracion-sugerida.csv).
- Los niveles solo se cambian con --aplicar-niveles, después de que una persona revise las sugerencias.
Los archivos no traen nombres ni correos. Los umbrales son una propuesta y deben calibrarse con el piloto.
"""
import sys,json,sqlite3,os,hashlib,csv
args=sys.argv[1:];aplicar='--aplicar-niveles' in args;args=[a for a in args if a!='--aplicar-niveles']
aqui=os.path.dirname(os.path.abspath(__file__));db=os.path.join(aqui,'banco-preguntas.db')
if '--db' in args:
    i=args.index('--db');db=args[i+1];del args[i:i+2]
files=[a for a in args if not a.startswith('--')]
if not files and not aplicar:sys.exit('Indica al menos un archivo datos-piloto.json')
if not os.path.exists(db):sys.exit(f'ERROR: no encuentro {db}')
MIN=10  # intentos mínimos para sacar conclusiones
c=sqlite3.connect(db)
c.executescript("""CREATE TABLE IF NOT EXISTS estadisticas(id_pregunta TEXT PRIMARY KEY,intentos INTEGER DEFAULT 0,aciertos INTEGER DEFAULT 0,ms_total INTEGER DEFAULT 0,n_tiempos INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS opciones_elegidas(id_pregunta TEXT,opcion TEXT,veces INTEGER DEFAULT 0,PRIMARY KEY(id_pregunta,opcion));
CREATE TABLE IF NOT EXISTS reportes(id INTEGER PRIMARY KEY AUTOINCREMENT,id_pregunta TEXT,motivo TEXT,fecha_ms INTEGER,examen TEXT,area TEXT,nivel TEXT,enunciado TEXT,UNIQUE(id_pregunta,motivo,fecha_ms));
CREATE TABLE IF NOT EXISTS validacion(id INTEGER PRIMARY KEY AUTOINCREMENT,examen TEXT,real_pct INTEGER,estimado_pct INTEGER,archivo TEXT);
CREATE TABLE IF NOT EXISTS retencion(id INTEGER PRIMARY KEY AUTOINCREMENT,archivo TEXT,dias_activos INTEGER,dias_json TEXT);
CREATE TABLE IF NOT EXISTS archivos_importados(hash TEXT PRIMARY KEY,nombre TEXT)""")
cols={r[1] for r in c.execute('PRAGMA table_info(estadisticas)')}
for k in('ms_total','n_tiempos'):
    if k not in cols:c.execute(f'ALTER TABLE estadisticas ADD COLUMN {k} INTEGER DEFAULT 0')
for f in files:
    raw=open(f,'rb').read();h=hashlib.sha256(raw).hexdigest()
    if c.execute('SELECT 1 FROM archivos_importados WHERE hash=?',(h,)).fetchone():print('Ya importado, se omite:',f);continue
    d=json.loads(raw.decode('utf-8'));nom=os.path.basename(f)
    for e in d.get('estadisticas',[]):
        c.execute('INSERT INTO estadisticas(id_pregunta,intentos,aciertos,ms_total,n_tiempos) VALUES(?,?,?,?,?) ON CONFLICT(id_pregunta) DO UPDATE SET intentos=intentos+excluded.intentos,aciertos=aciertos+excluded.aciertos,ms_total=ms_total+excluded.ms_total,n_tiempos=n_tiempos+excluded.n_tiempos',(e['id'],e['intentos'],e['aciertos'],e.get('ms_total',0),e.get('n_tiempos',0)))
        for op,n in (e.get('opciones') or {}).items():
            c.execute('INSERT INTO opciones_elegidas VALUES(?,?,?) ON CONFLICT(id_pregunta,opcion) DO UPDATE SET veces=veces+excluded.veces',(e['id'],op,n))
    for r in d.get('reportes',[]):
        c.execute('INSERT OR IGNORE INTO reportes(id_pregunta,motivo,fecha_ms,examen,area,nivel,enunciado) VALUES(?,?,?,?,?,?,?)',(r.get('id'),r.get('motivo'),r.get('t'),r.get('examen'),r.get('area'),r.get('nivel'),r.get('enunciado')))
        c.execute("UPDATE preguntas SET estado='revisar' WHERE id=? AND estado!='descartada'",(r.get('id'),))
    for v in d.get('validacion',[]):c.execute('INSERT INTO validacion(examen,real_pct,estimado_pct,archivo) VALUES(?,?,?,?)',(v.get('examen'),v.get('real_pct'),v.get('estimado_pct'),nom))
    for r in d.get('retencion',[]):c.execute('INSERT INTO retencion(archivo,dias_activos,dias_json) VALUES(?,?,?)',(nom,r.get('dias_activos',0),json.dumps(r.get('dias',[]))))
    c.execute('INSERT INTO archivos_importados VALUES(?,?)',(h,nom));print('Importado:',f)
c.commit()
def lista(t,sql,fmt):
    print('\n'+t)
    rows=c.execute(sql).fetchall()
    for r in rows:print('  '+fmt(r))
    if not rows:print('  (ninguna)')
lista(f'Preguntas con menos de 30 % de acierto ({MIN} o más intentos):',f'SELECT id_pregunta,intentos,aciertos FROM estadisticas WHERE intentos>={MIN} AND aciertos*1.0/intentos<0.3 ORDER BY aciertos*1.0/intentos LIMIT 15',lambda r:f'{r[0]}: {r[2]} de {r[1]}')
lista(f'Preguntas lentas (promedio de más de 40 s, {MIN} o más mediciones):',f'SELECT id_pregunta,ms_total*1.0/n_tiempos/1000,n_tiempos FROM estadisticas WHERE n_tiempos>={MIN} AND ms_total*1.0/n_tiempos>40000 ORDER BY 2 DESC LIMIT 15',lambda r:f'{r[0]}: {r[1]:.0f} s en promedio ({r[2]} mediciones)')
print('\nPreguntas donde una opción incorrecta se elige más que la correcta:')
n=0
for pid,inten in c.execute(f'SELECT id_pregunta,intentos FROM estadisticas WHERE intentos>={MIN}').fetchall():
    p=c.execute('SELECT opciones_json,respuesta FROM preguntas WHERE id=?',(pid,)).fetchone()
    if not p:continue
    ops=json.loads(p[0]);ok=next(o['texto'][:60] for o in ops if o['id']==p[1])
    ch=dict(c.execute('SELECT opcion,veces FROM opciones_elegidas WHERE id_pregunta=?',(pid,)).fetchall());vc=ch.get(ok,0)
    for t,v in ch.items():
        if t!=ok and v>vc:print(f'  {pid}: una opción incorrecta ({v} veces) atrae más que la correcta ({vc})');n+=1;break
if not n:print('  (ninguna)')
r=c.execute('SELECT COUNT(*),SUM(dias_activos>=2) FROM retencion').fetchone()
if r[0]:
    vuelve=0
    for (dj,) in c.execute('SELECT dias_json FROM retencion'):
        ds=sorted(json.loads(dj))
        from datetime import date,timedelta
        s={date.fromisoformat(x) for x in ds}
        if any(x+timedelta(days=1) in s for x in s):vuelve+=1
    print(f'\nRetención: {r[0]} participante(s); {r[1] or 0} con 2 o más días activos; {vuelve} volvieron al día siguiente.')
v=c.execute('SELECT COUNT(*),AVG(ABS(real_pct-estimado_pct)) FROM validacion WHERE estimado_pct IS NOT NULL').fetchone()
if v[0]:print(f'Validación del puntaje: {v[0]} caso(s), diferencia media de {v[1]:.1f} puntos porcentuales.')
NV=['Básico','Intermedio','Avanzado'];sug=[]
for pid,inten,ac in c.execute(f'SELECT id_pregunta,intentos,aciertos FROM estadisticas WHERE intentos>={MIN}').fetchall():
    p=c.execute('SELECT nivel,examen,area FROM preguntas WHERE id=?',(pid,)).fetchone()
    if not p or p[0] not in NV:continue
    a=ac/inten;ns=NV[0] if a>=0.75 else NV[1] if a>=0.45 else NV[2]
    if ns!=p[0]:sug.append((pid,p[1],p[2],p[0],ns,round(a*100),inten))
print(f'\nSugerencias de nivel (acierto observado: 75 % o más = Básico, 45 a 74 % = Intermedio, menos de 45 % = Avanzado): {len(sug)}')
if sug:
    dest=os.path.join(aqui,'recalibracion-sugerida.csv')
    with open(dest,'w',encoding='utf-8-sig',newline='') as fh:
        w=csv.writer(fh,delimiter=';');w.writerow(['id','examen','area','nivel_actual','nivel_sugerido','acierto_%','intentos']);w.writerows(sug)
    print('  Archivo:',dest)
    if aplicar:
        for pid,_,_,_,ns,_,_ in sug:c.execute('UPDATE preguntas SET nivel=?,version=version+1 WHERE id=?',(ns,pid))
        c.commit();print('  Niveles actualizados en la base (versión +1). Ejecuta actualizar_demo.py para verlos en el juego.')
    else:print('  Revisa el archivo; para aplicarlas usa --aplicar-niveles.')
